<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from yellostack.com/meric-saudi-arabia/courses/advanced-leadership-skills/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Nov 2020 09:19:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title><?php echo $this->Admin_model->translate("SAR") ?>Advanced Leadership Skills </title>
<link rel="icon" type="image/png" href="<?php echo base_url(); ?>assets/favicon.ico" />
<link href="https://fonts.googleapis.com/css?family=Rubik%3A%2C400%2C700%2C900%7CRoboto%3A%2C400%2C700%2C900%7Croboto%3A%2C400%2C700%2C900" rel="stylesheet"><!-- Optimized by SG Optimizer plugin version - 5.7.3 --><link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="My Blog &raquo; Feed" href="../../feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="My Blog &raquo; Comments Feed" href="../../comments/feed/index.html" />
	<script type="text/javascript">
		window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.3"}};
		!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
	</script>
	<style type="text/css">
img.wp-smiley,
img.emoji {
display: inline !important;
border: none !important;
box-shadow: none !important;
height: 1em !important;
width: 1em !important;
margin: 0 .07em !important;
vertical-align: -0.1em !important;
background: none !important;
padding: 0 !important;
}
</style>
<link rel='stylesheet' id='elementor-frontend-legacy-css'  href='assets/css/frontend-legacy.min2a45.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='assets/css/frontend.min2a45.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-138-css'  href='assets/elementor/css/post-1385473.css?ver=1605076533' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css'  href='assets/lib/font-awesome/css/all.min2a45.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css'  href='assets/lib/font-awesome/css/v4-shims.min2a45.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-521-css'  href='assets/elementor/css/post-521ac3f.css?ver=1605070287' type='text/css' media='all' />
<link rel='stylesheet' id='mec-select2-style-css'  href='assets/packages/select2/select2.minb51b.css?ver=5.13.5' type='text/css' media='all' />
<link rel='stylesheet' id='mec-font-icons-css'  href='assets/css/iconfonts5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='mec-frontend-style-css'  href='assets/css/frontend.minb51b.css?ver=5.13.5' type='text/css' media='all' />
<link rel='stylesheet' id='mec-tooltip-style-css'  href='assets/packages/tooltip/tooltip5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='mec-tooltip-shadow-style-css'  href='assets/packages/tooltip/tooltipster-sideTip-shadow.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='mec-featherlight-style-css'  href='assets/packages/featherlight/featherlight5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='mec-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Montserrat%3A400%2C700%7CRoboto%3A100%2C300%2C400%2C700&amp;ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='mec-lity-style-css'  href='assets/packages/lity/lity.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='../../wp-includes/css/dist/block-library/style.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='assets/packages/woocommerce-blocks/build/vendors-style6b00.css?ver=3.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='assets/packages/woocommerce-blocks/build/style6b00.css?ver=3.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='../../wp-includes/css/buttons.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='../../wp-includes/css/dashicons.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='editor-buttons-css'  href='../../wp-includes/css/editor.min5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-icon-css'  href='assets/icons/css/tutor-iconb34d.css?ver=1.7.4' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-plyr-css'  href='assets/packages/plyr/plyrb34d.css?ver=1.7.4' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-frontend-css'  href='assets/css/tutor-front.minb34d.css?ver=1.7.4' type='text/css' media='all' />
<style id='tutor-frontend-inline-css' type='text/css'>
:root{}
</style>
<link rel='stylesheet' id='tutor-gc-frontend-style-css'  href='assets/css/classroom-frontend5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='tutor-instructor-signature-css-css'  href='assets/css/instructor-signature5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='tutor_zoom_common_css-css'  href='assets/css/common8a54.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='tutor_zoom_frontend_css-css'  href='assets/css/frontend8a54.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='tutor_zoom_timepicker_css-css'  href='assets/css/jquery-ui-timepicker8a54.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='assets/css/woocommerce-layout83b6.css?ver=4.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='assets/css/woocommerce-smallscreen83b6.css?ver=4.6.2' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='assets/css/woocommerce83b6.css?ver=4.6.2' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='metform-ui-css'  href='assets/css/metform-uid36b.css?ver=1.3.9' type='text/css' media='all' />
<link rel='stylesheet' id='metform-style-css'  href='assets/css/styled36b.css?ver=1.3.9' type='text/css' media='all' />
<link rel='stylesheet' id='wur_content_css-css'  href='assets/css/content-page5697.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-ekiticons-css'  href='assets/css/ekiticonsad76.css?ver=5.9.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementskit-parallax-style-css'  href='assets/css/style7fb9.css?ver=1.5.9' type='text/css' media='all' />
<link rel='stylesheet' id='turitor-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CRubik%3A400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i&amp;ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='assets/css/bootstrap.min077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='assets/css/fontawesome.min077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='iconfont-css'  href='assets/css/iconfont077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='assets/css/magnific-popup077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css'  href='assets/css/owl.carousel.min077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='turitor-woocommerce-css'  href='assets/css/woocommerce077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='turitor-gutenberg-custom-css'  href='assets/css/gutenberg-custom077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='turitor-style-css'  href='assets/css/master077c.css?ver=1.2.9' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-css'  href='assets/css/widget-styles5bfb.css?ver=2.0.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-widget-styles-pro-css'  href='assets/css/widget-styles-pro5bfb.css?ver=2.0.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='ekit-responsive-css'  href='assets/css/responsive5bfb.css?ver=2.0.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='assets/lib/font-awesome/css/fontawesome.minb683.css?ver=5.12.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css'  href='assets/lib/font-awesome/css/solid.minb683.css?ver=5.12.0' type='text/css' media='all' />
<script type='text/javascript' src='assets/lib/font-awesome/js/v4-shims.min2a45.js?ver=3.0.13' id='font-awesome-4-shim-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' id='mec-frontend-script-js-extra'>
/* <![CDATA[ */
var mecdata = {"day":"day","days":"days","hour":"hour","hours":"hours","minute":"minute","minutes":"minutes","second":"second","seconds":"seconds","elementor_edit_mode":"no","recapcha_key":"","ajax_url":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","fes_nonce":"ab58b4b69b","current_year":"2020","current_month":"11","datepicker_format":"yy-mm-dd"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/frontendb51b.js?ver=5.13.5' id='mec-frontend-script-js'></script>
<script type='text/javascript' src='assets/js/eventsb51b.js?ver=5.13.5' id='mec-events-script-js'></script>
<script type='text/javascript' id='utils-js-extra'>
/* <![CDATA[ */
var userSettings = {"url":"\/meric-saudi-arabia\/","uid":"0","time":"1605086260","secure":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-includes/js/utils.min5697.js?ver=5.5.3' id='utils-js'></script>
<script type='text/javascript' src='assets/js/html2canvas.min5697.js?ver=5.5.3' id='html-to-image-converter-js'></script>
<script type='text/javascript' src='assets/js/js-pdf5697.js?ver=5.5.3' id='html-to-image-js-pdf-js'></script>
<script type='text/javascript' src='assets/js/html-to-image5697.js?ver=5.5.3' id='html-to-image-js'></script>
<script type='text/javascript' src='assets/js/instructor-signature5697.js?ver=5.5.3' id='tutor-instructor-signature-js-js'></script>
<script type='text/javascript' src='assets/js/content-page5697.js?ver=5.5.3' id='wur_review_content_script-js'></script>
<script type='text/javascript' src='assets/js/jarallax7fb9.js?ver=1.5.9' id='jarallax-js'></script>
<script type='text/javascript' src='assets/js/jquery.repeater.min077c.js?ver=1.2.9' id='jquery-repeater-min-js'></script>
<link rel="https://api.w.org/" href="../../wp-json/index.html" /><link rel="alternate" type="application/json" href="../../wp-json/wp/v2/courses/1977.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="../../xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../../wp-includes/wlwmanifest.xml" /> 
<link rel='next' title='php management' href='../php-management/index.html' />

<link rel='shortlink' href='../../indexa8b0.html?p=1977' />
<link rel="alternate" type="application/json+oembed" href="../../wp-json/oembed/1.0/embedb12f.json?url=https%3A%2F%2Fyellostack.com%2Fmeric-saudi-arabia%2Fcourses%2Fadvanced-leadership-skills%2F" />
<link rel="alternate" type="text/xml+oembed" href="../../wp-json/oembed/1.0/embedd453?url=https%3A%2F%2Fyellostack.com%2Fmeric-saudi-arabia%2Fcourses%2Fadvanced-leadership-skills%2F&amp;format=xml" />
    <script>
        var tutor_url_base="assets/index.html";
    </script>
			<!--Facebook-->
		<meta property="og:type" content="website"/>
		<meta property="og:image" content="https://yellostack.com/meric-saudi-arabia/wp-content/uploads/2020/11/Management.png" />
		<meta property="og:description" content="&lt;b&gt;Introduction&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course presents an opportunity for leaders and professionals to learn how to help their employees develop the appropriate leadership style in the workplace.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt; The course will also equip leaders to meet the challenge of developing excellent decision making skills.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt; Delegates will develop leadership skills based on the latest scientific findings on how make effective and creative decisions You will also learn how to apply flexible leadership skills in a practical way to help your team achieve its goals.&lt;/span&gt;

&nbsp;

&lt;b&gt;Who Should Attend:&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course is designed for anyone in a leadership role, department heads, supervisors, and team leaders who wish to learn more about strategies for improving leadership effectiveness in times of pressure, stress and crisis.&lt;/span&gt;

&nbsp;

&lt;b&gt;Objectives&lt;/b&gt;
&lt;ul&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Gain a greater awareness of yourself and your full leadership potential &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Refine your leadership styles for the benefit of your team and department &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Develop adaptability in dealing with different people &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Enhance decision making skills in employees &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Apply effective decision making skills in solving problems &lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
The Core Competencies

Participants will develop the following competencies:

Be more knowledgeable about your leadership style &amp; how to maximize it
Apply flexibility in various leadership situations
Learn how to motivate and to lead others better to improve their performance
Utilize understanding of personality styles to enhance your leadership
Apply leadership dynamics to understand others better
Encourage effective decision-making skills

&nbsp;

&nbsp;

&nbsp;

&nbsp;" />
		<!--Twitter-->
		<meta name="twitter:image" content="assets/2020/11/Management.png">
		<meta name="twitter:description" content="&lt;b&gt;Introduction&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course presents an opportunity for leaders and professionals to learn how to help their employees develop the appropriate leadership style in the workplace.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt; The course will also equip leaders to meet the challenge of developing excellent decision making skills.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;Delegates will develop leadership skills based on the latest scientific findings on how make effective and creative decisions You will also learn how to apply flexible leadership skills in a practical way to help your team achieve its goals.&lt;/span&gt;

&nbsp;

&lt;b&gt;Who Should Attend:&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course is designed for anyone in a leadership role, department heads, supervisors, and team leaders who wish to learn more about strategies for improving leadership effectiveness in times of pressure, stress and crisis.&lt;/span&gt;

&nbsp;

&lt;b&gt;Objectives&lt;/b&gt;
&lt;ul&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Gain a greater awareness of yourself and your full leadership potential &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Refine your leadership styles for the benefit of your team and department &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Develop adaptability in dealing with different people &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Enhance decision making skills in employees &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Apply effective decision making skills in solving problems &lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
The Core Competencies

Participants will develop the following competencies:

Be more knowledgeable about your leadership style &amp; how to maximize it
Apply flexibility in various leadership situations
Learn how to motivate and to lead others better to improve their performance
Utilize understanding of personality styles to enhance your leadership
Apply leadership dynamics to understand others better
Encourage effective decision-making skills

&nbsp;

&nbsp;

&nbsp;

&nbsp;">
		<!--Google+-->
		<meta itemprop="image" content="assets/2020/11/Management.png">
		<meta itemprop="description" content="&lt;b&gt;Introduction&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course presents an opportunity for leaders and professionals to learn how to help their employees develop the appropriate leadership style in the workplace.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt; The course will also equip leaders to meet the challenge of developing excellent decision making skills.&lt;/span&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;Delegates will develop leadership skills based on the latest scientific findings on how make effective and creative decisions You will also learn how to apply flexible leadership skills in a practical way to help your team achieve its goals.&lt;/span&gt;

&nbsp;

&lt;b&gt;Who Should Attend:&lt;/b&gt;

&lt;span style=&quot;font-weight: 400;&quot;&gt;This course is designed for anyone in a leadership role, department heads, supervisors, and team leaders who wish to learn more about strategies for improving leadership effectiveness in times of pressure, stress and crisis.&lt;/span&gt;

&nbsp;

&lt;b&gt;Objectives&lt;/b&gt;
&lt;ul&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Gain a greater awareness of yourself and your full leadership potential &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Refine your leadership styles for the benefit of your team and department &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Develop adaptability in dealing with different people &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Enhance decision making skills in employees &lt;/span&gt;&lt;/li&gt;
	&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Apply effective decision making skills in solving problems &lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
The Core Competencies

Participants will develop the following competencies:

Be more knowledgeable about your leadership style &amp; how to maximize it
Apply flexibility in various leadership situations
Learn how to motivate and to lead others better to improve their performance
Utilize understanding of personality styles to enhance your leadership
Apply leadership dynamics to understand others better
Encourage effective decision-making skills

&nbsp;

&nbsp;

&nbsp;

&nbsp;"> <script>
			window.tutor_gc_base_url="index.html";
			window.tutor_gc_loading_icon_url="../../wp-admin/images/loading.gif";
			window.tutor_gc_ajax_url="../../wp-admin/admin-ajax.html";
			window.tutor_gc_dashboard_url="../../profile/index.html";
		</script><script>var tutor_loading_icon_url="../../wp-admin/images/loading.gif";</script>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>

		<script type="text/javascript">
			var elementskit_module_parallax_url = "index.html"
		</script>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>		
    	<?php include 'header.php'?>

			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6a6d3ddb" data-id="6a6d3ddb" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-d7665fb elementor-widget elementor-widget-elementskit-header-search" data-id="d7665fb" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-header-search.default">
			<div class="elementor-widget-container">
		<div class="ekit-wid-con" >        <a href="#ekit_modal-popup-d7665fb" class="ekit_navsearch-button ekit-modal-popup">
        <i aria-hidden="true" class="icon icon-search"></i>        </a>
    <!-- language switcher strart -->
    <!-- xs modal -->
    <div class="zoom-anim-dialog mfp-hide ekit_modal-searchPanel" id="ekit_modal-popup-d7665fb">
        <div class="ekit-search-panel">
        <!-- Polylang search - thanks to Alain Melsens -->
            <form role="search" method="get" class="ekit-search-group" action="https://yellostack.com/meric-saudi-arabia/">
                <input type="search" class="ekit_search-field" placeholder="Search..." value="" name="s" />
                <button type="submit" class="ekit_search-button">
                    <i aria-hidden="true" class="icon icon-search"></i>                    </button>
            </form>
        </div>
    </div><!-- End xs modal -->
    <!-- end language switcher strart -->
    </div>		</div>
			</div>
					</div>
				</div>
	</div>
			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5481ab4f" data-id="5481ab4f" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-17468421 elementor-view-default elementor-widget elementor-widget-icon" data-id="17468421" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="icon.default">
			<div class="elementor-widget-container">
				<div class="elementor-icon-wrapper">
		<a class="elementor-icon" href="../../profile/index.html">
		<i aria-hidden="true" class="fas fa-user"></i>			</a>
	</div>
			</div>
			</div>
					</div>
				</div>
	</div>
							</div>
				</div>
	</section>
					</div>
				</div>
	</div>
							</div>
				</div>
	</section>
					</div>
					</div>
				</div>
	</div>

<div class="tutor-wrap tutor-full-width-course-top tutor-course-top-info tutor-page-wrap post-1977 courses type-courses status-publish has-post-thumbnail hentry course-category-classroom-training course-category-virtual-instructor course-tag-management">
<div class="tutor-container">
    <div class="tutor-row">
        <div class="tutor-col-8 tutor-col-md-100">
            	            
<div class="tutor-single-course-segment tutor-single-course-lead-info">


    <h1 class="tutor-course-header-h1"><?php echo $this->Admin_model->translate("Advanced Leadership Skills") ?></h1>

	
<div class="tutor-single-course-meta tutor-meta-top">
            <ul>
        
        
                </ul>

</div>

<div class="tutor-single-course-meta tutor-lead-meta">
    <ul>
		                <li>
                <span><?php echo $this->Admin_model->translate("Categories") ?></span>
				<a href='../../course-category/classroom-training/index.html'><?php echo $this->Admin_model->translate("Public Classrooms") ?></a><a href='../../course-category/virtual-instructor/index.html'><?php echo $this->Admin_model->translate("Virtual Instructor") ?></a>                </li>
		
                        <li>
                <span><?php echo $this->Admin_model->translate("Duration") ?></span>
                <?php echo $this->Admin_model->translate("4h") ?>               </li>
                </ul>
</div>

	


</div>	            
<div class="tutor-single-course-segment  tutor-course-content-wrap">
	            <div class="course-content-title">
            <h4  class="tutor-segment-title"><?php echo $this->Admin_model->translate("Description") ?></h4>
        </div>
		

    <div class="tutor-course-content-content">
		<p><b><?php echo $this->Admin_model->translate("Introduction") ?></b></p>
<p><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("This course presents an opportunity for leaders and professionals to learn how to help their employees develop the appropriate leadership style in the workplace.") ?></span></p>
<p><span style="font-weight: 400;"> <?php echo $this->Admin_model->translate("The course will also equip leaders to meet the challenge of developing excellent decision making skills.") ?></span></p>
<p><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Delegates will develop leadership skills based on the latest scientific findings on how make effective and creative decisions You will also learn how to apply flexible leadership skills in a practical way to help your team achieve its goals.") ?></span></p>
<p>&nbsp;</p>
<p><b><?php echo $this->Admin_model->translate("Who Should Attend:") ?></b></p>
<p><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("This course is designed for anyone in a leadership role, department heads, supervisors, and team leaders who wish to learn more about strategies for improving leadership effectiveness in times of pressure, stress and crisis.") ?></span></p>
<p>&nbsp;</p>
<p><b><?php echo $this->Admin_model->translate("Objectives") ?></b></p>
<ul>
<li style="font-weight: 400;"><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Gain a greater awareness of yourself and your full leadership potential ") ?></span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Refine your leadership styles for the benefit of your team and department") ?> </span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Develop adaptability in dealing with different people") ?> </span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Enhance decision making skills in employees") ?> </span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"><?php echo $this->Admin_model->translate("Apply effective decision making skills in solving problems ") ?></span></li>
</ul>
<p><?php echo $this->Admin_model->translate("The Core Competencies") ?></p>
<p><?php echo $this->Admin_model->translate("Participants will develop the following competencies:") ?></p>
<p><?php echo $this->Admin_model->translate("Be more knowledgeable about your leadership style") ?> &amp; <?php echo $this->Admin_model->translate("how to maximize it") ?><br /><?php echo $this->Admin_model->translate("Apply flexibility in various leadership situations") ?>
<br />
<?php echo $this->Admin_model->translate("Learn how to motivate and to lead others better to improve their performance") ?><br />
<?php echo $this->Admin_model->translate("Utilize understanding of personality styles to enhance your leadership") ?><br />
<?php echo $this->Admin_model->translate("Apply leadership dynamics to understand others better") ?><br />
<?php echo $this->Admin_model->translate("Encourage effective decision-making skills") ?></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    </div>
</div>


            	            


<div class="tutor-single-course-segment  tutor-course-topics-wrap">
    <div class="tutor-course-topics-header">
        <div class="tutor-course-topics-header-left">
            <h4 class="tutor-segment-title"><?php echo $this->Admin_model->translate("Topics for this course</h4>") ?>
        </div>
        <div class="tutor-course-topics-header-right">
			<span> 5 <?php echo $this->Admin_model->translate("Lessons") ?></span><span>4h </span>            </div>
    </div>
    <div class="tutor-course-topics-contents">
		
                <div class="tutor-course-topic tutor-topics-in-single-lesson tutor-active">
                    <div class="tutor-course-title ">
                        <h4> 
							<i class="tutor-icon-plus"></i> 
							<?php echo $this->Admin_model->translate("Course Outlines") ?>							</h4>
                    </div>

					
                    <div class="tutor-course-lessons" style="">

						
                                <div class="tutor-course-lesson">
                                    <h5>
										<a href="lesson/day-one/index.html"><span class="lesson-preview-title"><i class='tutor-icon-document-alt'></i><?php echo $this->Admin_model->translate("Day One") ?></span></a>                                        </h5>
                                </div>

								
                                <div class="tutor-course-lesson">
                                    <h5>
										<a href="lesson/day-two/index.html"><span class="lesson-preview-title"><i class='tutor-icon-document-alt'></i><?php echo $this->Admin_model->translate("Day Two") ?></span></a>                                        </h5>
                                </div>

								
                                <div class="tutor-course-lesson">
                                    <h5>
										<a href="lesson/day-three/index.html"><span class="lesson-preview-title"><i class='tutor-icon-document-alt'></i><?php echo $this->Admin_model->translate("Day Three") ?></span></a>                                        </h5>
                                </div>

								
                                <div class="tutor-course-lesson">
                                    <h5>
										<a href="lesson/day-four/index.html"><span class="lesson-preview-title"><i class='tutor-icon-document-alt'></i><?php echo $this->Admin_model->translate("Day Four") ?></span></a>                                        </h5>
                                </div>

								
                                <div class="tutor-course-lesson">
                                    <h5>
										<a href="lesson/day-five/index.html"><span class="lesson-preview-title"><i class='tutor-icon-document-alt'></i><?php echo $this->Admin_model->translate("SAR") ?></span></a>                                        </h5>
                                </div>

								                        </div>
                </div>
				        </div>
</div>


            	<h4 class="tutor-segment-title"><?php echo $this->Admin_model->translate("About the instructor") ?></h4>

<div class="tutor-course-instructors-wrap tutor-single-course-segment" id="single-course-ratings">
				<div class="single-instructor-wrap">
			<div class="single-instructor-top">
                <div class="tutor-instructor-left">
                    <div class="instructor-avatar">
                        <a href="../../profile/meric/index.html">
                            <span class='tutor-text-avatar' style='background-color: #9ee9d8; color: #fff8e5'><?php echo $this->Admin_model->translate("ME") ?></span>                            </a>
                    </div>

                    <div class="instructor-name">
                        <h3><a href="../../profile/meric/index.html"><?php echo $this->Admin_model->translate("meric") ?></a> </h3>
                                                </div>
                </div>
				<div class="instructor-bio">
										</div>
			</div>

            
			<div class="single-instructor-bottom">
				<div class="ratings">
					<span class="rating-generated">
						<div class="tutor-star-rating-group"><i class="tutor-icon-star-line" data-rating-value="1"></i><i class="tutor-icon-star-line" data-rating-value="2"></i><i class="tutor-icon-star-line" data-rating-value="3"></i><i class="tutor-icon-star-line" data-rating-value="4"></i><i class="tutor-icon-star-line" data-rating-value="5"></i><div class='tutor-rating-gen-input'><input type='hidden' name='tutor_rating_gen_input' value='0' /> </div></div>						</span>

					 <span class='rating-digits'>0</span>  <span class='rating-total-meta'>(0 <?php echo $this->Admin_model->translate("ratings") ?>)</span> 					</div>

				<div class="courses">
					<p>
						<i class='tutor-icon-mortarboard'></i>
						17 <span class="tutor-text-mute"> <?php echo $this->Admin_model->translate("Courses") ?></span>
					</p>
				</div>

				<div class="students">
					
					<p>
						<i class='tutor-icon-user'></i>
						9							<span class="tutor-text-mute"> <?php echo $this->Admin_model->translate("students") ?> </span>
					</p>
				</div>
			</div>
		</div>
			</div>
                	                        </div> <!-- .tutor-col-8 -->

        <div class="tutor-col-4">
            <div class="tutor-single-course-sidebar">
                                    
<div class="tutor-price-preview-box">
<div class="tutor-price-box-thumbnail">
	<img width="313" height="311" src="assets/2020/11/Management.png" class="attachment-post-thumbnail size-post-thumbnail" alt="" loading="lazy" srcset="https://yellostack.com/meric-saudi-arabia/wp-content/uploads/2020/11/Management.png 313w, https://yellostack.com/meric-saudi-arabia/wp-content/uploads/2020/11/Management-300x298.png 300w, https://yellostack.com/meric-saudi-arabia/wp-content/uploads/2020/11/Management-150x150.png 150w" sizes="(max-width: 313px) 100vw, 313px" />    </div>


	<div class="price">
	<?php echo $this->Admin_model->translate("Free") ?>	</div>
	    
<div class="tutor-single-add-to-cart-box cart-required-login " data-login_page_url="">
		<form class="tutor-enroll-form" method="post">
		<input type="hidden" id="_wpnonce" name="_wpnonce" value="c1ab78139e" /><input type="hidden" name="_wp_http_referer" value="/meric-saudi-arabia/courses/advanced-leadership-skills/" />			<input type="hidden" name="tutor_course_id" value="1977">
		<input type="hidden" name="tutor_course_action" value="_tutor_course_enroll_now">

		<div class=" tutor-course-enroll-wrap">
			<button type="submit" class="tutor-btn-enroll tutor-btn tutor-course-purchase-btn">
				<?php echo $this->Admin_model->translate("Enroll Now") ?>				</button>
		</div>
	</form>

</div>

<div class='tutor-cart-box-login-form' style='display: none;'><span class='login-overlay-close'></span><div class='tutor-cart-box-login-form-inner'><button class='tutor-popup-form-close tutor-icon-line-cross'></button>
<div class="tutor-single-course-segment tutor-course-login-wrap">
<div class="course-login-title">
    <h4><?php echo $this->Admin_model->translate("Login") ?></h4>
</div>

<div class="tutor-single-course-login-form">
    
<div class="tutor-login-form-wrap">


<form name="loginform" id="loginform" method="post">


<input type="hidden" id="_wpnonce" name="_wpnonce" value="c1ab78139e" /><input type="hidden" name="_wp_http_referer" value="/meric-saudi-arabia/courses/advanced-leadership-skills/" />	
<input type="hidden" name="tutor_action" value="tutor_user_login" />
	<p class="login-username">
		<input type="text" placeholder="Username or Email Address" name="log" id="user_login" class="input" value="" size="20" />
	</p>

	<p class="login-password">
		<input type="password" placeholder="Password" name="pwd" id="user_pass" class="input" value="" size="20"/>

	</p>
	
	

	<div class="tutor-login-rememeber-wrap">
					<p class="login-remember">
			<label>
				<input name="rememberme" type="checkbox" id="rememberme" 
				value="forever" 
				 					>
				<?php echo $this->Admin_model->translate("Remember Me") ?>			</label>
		</p>
				    <a href="../../profile/retrieve-password/index.html">
	    	<?php echo $this->Admin_model->translate("Forgot Password?") ?>		    </a>
	</div>
	
	
	<p class="login-submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Log In" />
		<input type="hidden" name="redirect_to" value="index.html" />
	</p>
	
	<p class="tutor-form-register-wrap">
	    <a href="../../student-registration/index73bc.html?redirect_to=https://yellostack.com/meric-saudi-arabia/courses/advanced-leadership-skills/">
	    	<?php echo $this->Admin_model->translate("Create a new account") ?>		    </a>
    </p>
</form>

</div>
</div>
</div>
</div></div>
</div> <!-- tutor-price-preview-box -->
                                        <div class="tutor-single-course-segment">
    <div class="course-benefits-title">
        <h4 class="tutor-segment-title"><?php echo $this->Admin_model->translate("Tags") ?></h4>
    </div>
    <div class="tutor-course-tags">
        <a href='../../course-tag/management/index.html'> <?php echo $this->Admin_model->translate("management") ?> </a>        </div>
</div>
                                                    </div>
        </div>
    </div>
</div>
</div>


<div class="ekit-template-content-markup ekit-template-content-footer ekit-template-content-theme-support">
<style>.elementor-521 .elementor-element.elementor-element-d552d7b:not(.elementor-motion-effects-element-type-background), .elementor-521 .elementor-element.elementor-element-d552d7b > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#062E38;}.elementor-521 .elementor-element.elementor-element-d552d7b > .elementor-background-overlay{background-color:#062E38;opacity:1;transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-521 .elementor-element.elementor-element-d552d7b{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:50px 0px 20px 0px;overflow:visible;}.elementor-521 .elementor-element.elementor-element-7406752:not(.elementor-motion-effects-element-type-background) > .elementor-column-wrap, .elementor-521 .elementor-element.elementor-element-7406752 > .elementor-column-wrap > .elementor-motion-effects-container > .elementor-motion-effects-layer{background-color:#062E38;}.elementor-521 .elementor-element.elementor-element-7406752 > .elementor-element-populated{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-521 .elementor-element.elementor-element-7406752 > .elementor-element-populated > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-521 .elementor-element.elementor-element-f35046a{overflow:visible;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-section-title{color:#FFFFFF;margin:0px 0px 5px 0px;font-size:18px;font-weight:700;text-transform:uppercase;line-height:24px;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-section-title > span{color:#000000;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-divider{width:18px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long{width:18px;height:3px;color:#F5B016;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-star{width:18px;height:3px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 38%, rgba(255, 255, 255, 0) 38%, rgba(255, 255, 255, 0) 62%, #F5B016 62%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-divider, .elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-border-divider::before{height:3px;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-divider:before{background-color:#F5B016;box-shadow:9px 0px 0px 0px #F5B016, 18px 0px 0px 0px #F5B016;}.elementor-521 .elementor-element.elementor-element-e37d5fd .elementskit-section-title-wraper .elementskit-border-star:after{background-color:#F5B016;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-section-title{color:#FFFFFF;margin:0px 0px 5px 0px;font-size:18px;font-weight:700;text-transform:uppercase;line-height:24px;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-section-title > span{color:#000000;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-divider{width:18px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long{width:18px;height:3px;color:#F5B016;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-star{width:18px;height:3px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 38%, rgba(255, 255, 255, 0) 38%, rgba(255, 255, 255, 0) 62%, #F5B016 62%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-divider, .elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-border-divider::before{height:3px;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-divider:before{background-color:#F5B016;box-shadow:9px 0px 0px 0px #F5B016, 18px 0px 0px 0px #F5B016;}.elementor-521 .elementor-element.elementor-element-07cfac9 .elementskit-section-title-wraper .elementskit-border-star:after{background-color:#F5B016;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-section-title{color:#FFFFFF;margin:0px 0px 5px 0px;font-size:18px;font-weight:700;text-transform:uppercase;line-height:24px;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-section-title > span{color:#000000;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-divider{width:18px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-divider.elementskit-style-long{width:18px;height:3px;color:#F5B016;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-star{width:18px;height:3px;background:linear-gradient(90deg, #F5B016 0%, #F5B016 38%, rgba(255, 255, 255, 0) 38%, rgba(255, 255, 255, 0) 62%, #F5B016 62%, #F5B016 100%);}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-divider, .elementor-521 .elementor-element.elementor-element-5941500 .elementskit-border-divider::before{height:3px;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-divider:before{background-color:#F5B016;box-shadow:9px 0px 0px 0px #F5B016, 18px 0px 0px 0px #F5B016;}.elementor-521 .elementor-element.elementor-element-5941500 .elementskit-section-title-wraper .elementskit-border-star:after{background-color:#F5B016;}.elementor-521 .elementor-element.elementor-element-a02f087 .ekit_socialshare{text-align:left;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-a34ffda > a{color:#FFFFFF;border-style:solid;border-width:2px 2px 2px 2px;border-color:rgba(255, 255, 255, 0.2);}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-a34ffda > a svg path{stroke:#FFFFFF;fill:#FFFFFF;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-a34ffda > a:hover{background-color:#3b5998;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-d5a0fda > a{color:#FFFFFF;border-style:solid;border-width:2px 2px 2px 2px;border-color:rgba(255, 255, 255, 0.2);}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-d5a0fda > a svg path{stroke:#FFFFFF;fill:#FFFFFF;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-d5a0fda > a:hover{background-color:#1da1f2;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-7fb877f > a{color:#FFFFFF;border-style:solid;border-width:2px 2px 2px 2px;border-color:rgba(255, 255, 255, 0.2);}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-7fb877f > a svg path{stroke:#FFFFFF;fill:#FFFFFF;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-7fb877f > a:hover{background-color:#1da1f2;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-53ac344 > a{color:#FFFFFF;border-style:solid;border-width:2px 2px 2px 2px;border-color:rgba(255, 255, 255, 0.2);}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-53ac344 > a svg path{stroke:#FFFFFF;fill:#FFFFFF;}.elementor-521 .elementor-element.elementor-element-a02f087 .elementor-repeater-item-53ac344 > a:hover{background-color:#0077b5;}.elementor-521 .elementor-element.elementor-element-a02f087 .ekit_socialshare > li > a{text-align:center;text-decoration:none;border-radius:50% 50% 50% 50%;width:40px;height:40px;line-height:35px;}.elementor-521 .elementor-element.elementor-element-a02f087 .ekit_socialshare > li{display:inline-block;margin:0px 5px 0px 0px;}.elementor-521 .elementor-element.elementor-element-a02f087 .ekit_socialshare > li > a i{font-size:15px;}.elementor-521 .elementor-element.elementor-element-a02f087 .ekit_socialshare > li > a svg{max-width:15px;}.elementor-521 .elementor-element.elementor-element-95c4384{--divider-border-style:solid;--divider-color:rgba(255, 255, 255, 0.15);--divider-border-width:1px;}.elementor-521 .elementor-element.elementor-element-95c4384 .elementor-divider-separator{width:100%;}.elementor-521 .elementor-element.elementor-element-95c4384 > .elementor-widget-container{margin:20px 0px 13px 0px;}.elementor-521 .elementor-element.elementor-element-95e7ecd > .elementor-container > .elementor-row > .elementor-column > .elementor-column-wrap > .elementor-widget-wrap{align-content:center;align-items:center;}.elementor-521 .elementor-element.elementor-element-95e7ecd{overflow:visible;}.elementor-521 .elementor-element.elementor-element-ed2d21d > .elementor-element-populated{margin:0px 0px 0px 0px;}.elementor-521 .elementor-element.elementor-element-f4dd33e .ts-scroll-box .BackTo{background-color:#F5B016;color:#FFFFFF;text-align:center;padding:11px 0px 0px 0px;}.elementor-521 .elementor-element.elementor-element-f4dd33e .ts-scroll-box .BackTo:hover{background-color:#FA4142;}.elementor-521 .elementor-element.elementor-element-f4dd33e > .elementor-widget-container{margin:45px 0px 0px 0px;padding:0rem 0rem 0rem 3rem;}@media(min-width:768px){.elementor-521 .elementor-element.elementor-element-ed2d21d{width:50%;}.elementor-521 .elementor-element.elementor-element-93d17cb{width:2.993%;}}@media(max-width:1024px){.elementor-521 .elementor-element.elementor-element-6ea10fd .turitor-widget-logo{text-align:center;}}@media(max-width:767px){.elementor-521 .elementor-element.elementor-element-6ea10fd .turitor-widget-logo{text-align:center;}}@media(max-width:1024px) and (min-width:768px){.elementor-521 .elementor-element.elementor-element-90a3482{width:50%;}.elementor-521 .elementor-element.elementor-element-5f292b4{width:50%;}.elementor-521 .elementor-element.elementor-element-741dbfe{width:50%;}.elementor-521 .elementor-element.elementor-element-29b19d2{width:100%;}.elementor-521 .elementor-element.elementor-element-ed2d21d{width:100%;}.elementor-521 .elementor-element.elementor-element-93d17cb{width:20%;}}/* Start custom CSS for wp-widget-nav_menu, class: .elementor-element-7033745 */.ts-footer-menu a{
color:white; 
list-style:none;
}
.ts-footer-menu li{
list-style:none;
}/* End custom CSS */</style>		<div data-elementor-type="wp-post" data-elementor-id="521" class="elementor elementor-521" data-elementor-settings="[]">
					<div class="elementor-inner">
						<div class="elementor-section-wrap">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-d552d7b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d552d7b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
						<div class="elementor-background-overlay"></div>
						<div class="elementor-container elementor-column-gap-default">
						<div class="elementor-row">
				<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7406752" data-id="7406752" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<section class="elementor-section elementor-inner-section elementor-element elementor-element-f35046a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f35046a" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
					<div class="elementor-container elementor-column-gap-default">
						<div class="elementor-row">
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-90a3482" data-id="90a3482" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-e37d5fd elementor-widget elementor-widget-elementskit-heading" data-id="e37d5fd" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
			<div class="elementor-widget-container">
		<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
			<?php echo $this->Admin_model->translate("Company") ?>	
			</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
			</div>
			<div class="elementor-element elementor-element-8a77926 elementor-widget elementor-widget-text-editor" data-id="8a77926" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
			<div class="elementor-widget-container">
				<div class="elementor-text-editor elementor-clearfix"><p style="color:white;"><?php echo $this->Admin_model->translate("SAR") ?><?php echo $this->Admin_model->translate("In 1958 MEIRC ( Middle East Industrial Relations Consultants ) was founded in Athens serving the Gulf market. In 1982, the company was fully transformed to MEIRC Saudi Arabia with full rights and privileges.") ?></p></div>
			</div>
			</div>
					</div>
				</div>
	</div>
			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5f292b4" data-id="5f292b4" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-07cfac9 elementor-widget elementor-widget-elementskit-heading" data-id="07cfac9" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
			<div class="elementor-widget-container">
		<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
				<?php echo $this->Admin_model->translate("Course Type") ?>
			</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
			</div>
			<div class="elementor-element elementor-element-7033745 ts-footer-menu elementor-widget elementor-widget-wp-widget-nav_menu" data-id="7033745" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="wp-widget-nav_menu.default">
			<div class="elementor-widget-container">
		<div class="menu-categories-container"><ul id="menu-categories" class="menu"><li id="menu-item-2704" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2704"><a href="../indexac75.html?s=&amp;course_category%5B%5D=32"><?php echo $this->Admin_model->translate("Classroom Training") ?></a></li>
<li id="menu-item-2705" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2705"><a href="../indexc20a.html?s=&amp;course_category%5B%5D=33"><?php echo $this->Admin_model->translate("Online Training(Self Paced)") ?></a></li>
<li id="menu-item-2706" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2706"><a href="../index9e7a.html?s=&amp;course_category%5B%5D=34"><?php echo $this->Admin_model->translate("Virtual Instructor") ?></a></li>
<li id="menu-item-2707" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2707"><a href="#"><?php echo $this->Admin_model->translate("In House Training") ?></a></li>
</ul></div>		</div>
			</div>
					</div>
				</div>
	</div>
			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-741dbfe" data-id="741dbfe" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-5941500 elementor-widget elementor-widget-elementskit-heading" data-id="5941500" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
			<div class="elementor-widget-container">
		<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
				<?php echo $this->Admin_model->translate("Get in touch") ?>
			</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
			</div>
			<div class="elementor-element elementor-element-91f569d elementor-widget elementor-widget-text-editor" data-id="91f569d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
			<div class="elementor-widget-container">
				<div class="elementor-text-editor elementor-clearfix"><p style="color:white"><?php echo $this->Admin_model->translate("Email") ?>: manager@mericsa.com</p>
<p style="color:white"><?php echo $this->Admin_model->translate("Phone-no") ?> :&nbsp;  +966133412188<br>
<?php echo $this->Admin_model->translate("Fax-no") ?> :&nbsp;&nbsp;  &nbsp;  &nbsp; +966133415046<br>
<?php echo $this->Admin_model->translate("mobile-no") ?>:&nbsp; &nbsp;+966505949708
</p></div>
			</div>
			</div>
			<div class="elementor-element elementor-element-a02f087 elementor-widget elementor-widget-elementskit-social-share" data-id="a02f087" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-social-share.default">
			<div class="elementor-widget-container">
		<div class="ekit-wid-con" >		<ul class="ekit_socialshare">
                                        <li class="elementor-repeater-item-a34ffda" data-social="facebook">
                <a class="facebook">
                    
                    <i aria-hidden="true" class="icon icon-facebook"></i>                        
                                                                                        </a>
            </li>
                                                        <li class="elementor-repeater-item-d5a0fda" data-social="twitter">
                <a class="twitter">
                    
                    <i aria-hidden="true" class="icon icon-twitter"></i>                        
                                                                                        </a>
            </li>
                                                        <li class="elementor-repeater-item-7fb877f" data-social="instagram">
                <a class="instagram">
                    
                    <i aria-hidden="true" class="icon icon-instagram-1"></i>                        
                                                                                        </a>
            </li>
                                                        <li class="elementor-repeater-item-53ac344" data-social="linkedin">
                <a class="linkedin">
                    
                    <i aria-hidden="true" class="icon icon-linkedin"></i>                        
                                                                                        </a>
            </li>
                                </ul>
    </div>		</div>
			</div>
					</div>
				</div>
	</div>
							</div>
				</div>
	</section>
			<div class="elementor-element elementor-element-95c4384 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="95c4384" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="divider.default">
			<div class="elementor-widget-container">
				<div class="elementor-divider">
		<span class="elementor-divider-separator">
					</span>
	</div>
			</div>
			</div>
			<section class="elementor-section elementor-inner-section elementor-element elementor-element-95e7ecd elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="95e7ecd" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
					<div class="elementor-container elementor-column-gap-default">
						<div class="elementor-row">
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-29b19d2" data-id="29b19d2" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-6ea10fd elementor-widget elementor-widget-turitor-logo" data-id="6ea10fd" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="turitor-logo.default">
			<div class="elementor-widget-container">
		    <div class="turitor-widget-logo">
    <a href="../../index.html">
        <img src="2020/10/Group-48.png" alt="My Blog">
    </a>
</div>

		</div>
			</div>
					</div>
				</div>
	</div>
			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ed2d21d" data-id="ed2d21d" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-7d3f16a elementor-widget elementor-widget-text-editor" data-id="7d3f16a" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
			<div class="elementor-widget-container">
				<div class="elementor-text-editor elementor-clearfix"><p class="text-right" style="color:white">© 2020. <?php echo $this->Admin_model->translate("All rights reserved.") ?></p></div>
			</div>
			</div>
					</div>
				</div>
	</div>
			<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-93d17cb elementor-hidden-tablet" data-id="93d17cb" data-element_type="column">
		<div class="elementor-column-wrap elementor-element-populated">
						<div class="elementor-widget-wrap">
					<div class="elementor-element elementor-element-f4dd33e elementor-widget elementor-widget-turitor-back-to-top" data-id="f4dd33e" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="turitor-back-to-top.default">
			<div class="elementor-widget-container">
		      
  <div class="ts-scroll-box">
		<div class="BackTo">
			<a href="#">
				<i aria-hidden="true" class="tsicon tsicon-up_arrow"></i>				</a>
		</div>
  </div>
 

  

		</div>
			</div>
					</div>
				</div>
	</div>
							</div>
				</div>
	</section>
					</div>
				</div>
	</div>
							</div>
				</div>
	</section>
					</div>
					</div>
				</div>
	</div>
<div class='tutor-cart-box-login-form' style='display: none;'><span class='login-overlay-close'></span><div class='tutor-cart-box-login-form-inner'><button class='tutor-popup-form-close tutor-icon-line-cross'></button>
<div class="tutor-single-course-segment tutor-course-login-wrap">
<div class="course-login-title">
    <h4><?php echo $this->Admin_model->translate("Login") ?></h4>
</div>

<div class="tutor-single-course-login-form">
    
<div class="tutor-login-form-wrap">


<form name="loginform" id="loginform" method="post">


<input type="hidden" id="_wpnonce" name="_wpnonce" value="c1ab78139e" /><input type="hidden" name="_wp_http_referer" value="/meric-saudi-arabia/courses/advanced-leadership-skills/" />	
<input type="hidden" name="tutor_action" value="tutor_user_login" />
	<p class="login-username">
		<input type="text" placeholder="Username or Email Address" name="log" id="user_login" class="input" value="" size="20" />
	</p>

	<p class="login-password">
		<input type="password" placeholder="Password" name="pwd" id="user_pass" class="input" value="" size="20"/>

	</p>
	
	

	<div class="tutor-login-rememeber-wrap">
					<p class="login-remember">
			<label>
				<input name="rememberme" type="checkbox" id="rememberme" 
				value="forever" 
				 					>
				<?php echo $this->Admin_model->translate("Remember Me") ?>				</label>
		</p>
				    <a href="../../profile/retrieve-password/index.html">
	    	<?php echo $this->Admin_model->translate("Forgot Password?") ?>		    </a>
	</div>
	
	
	<p class="login-submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Log In" />
		<input type="hidden" name="redirect_to" value="index.html" />
	</p>
	
	<p class="tutor-form-register-wrap">
	    <a href="../../student-registration/index73bc.html?redirect_to=https://yellostack.com/meric-saudi-arabia/courses/advanced-leadership-skills/">
	    <?php echo $this->Admin_model->translate("Create a new account") ?>			    </a>
    </p>
</form>

</div>
</div>
</div>
</div></div>	<script type="text/javascript">
	(function () {
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	})()
</script>
<link rel='stylesheet' id='elementor-icons-css'  href='assets/lib/eicons/css/elementor-icons.min74e5.css?ver=5.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='assets/lib/animations/animations.min2a45.css?ver=3.0.13' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-post-12-css'  href='assets/elementor/css/post-12cebc.css?ver=1604557406' type='text/css' media='all' />
<link rel='stylesheet' id='metform-css-formpicker-control-editor-css'  href='assets/css/form-picker-editor8a54.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementskit-css-widgetarea-control-editor-css'  href='assets/css/widgetarea-editor5bfb.css?ver=2.0.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;ver=5.5.3' type='text/css' media='all' />
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/core.mine899.js?ver=1.11.4' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/datepicker.mine899.js?ver=1.11.4' id='jquery-ui-datepicker-js'></script>
<script type='text/javascript' id='jquery-ui-datepicker-js-after'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript' src='assets/js/jquery.typewatchb51b.js?ver=5.13.5' id='mec-typekit-script-js'></script>
<script type='text/javascript' src='assets/packages/featherlight/featherlightb51b.js?ver=5.13.5' id='mec-featherlight-script-js'></script>
<script type='text/javascript' src='assets/packages/select2/select2.full.minb51b.js?ver=5.13.5' id='mec-select2-script-js'></script>
<script type='text/javascript' src='assets/packages/tooltip/tooltipb51b.js?ver=5.13.5' id='mec-tooltip-script-js'></script>
<script type='text/javascript' src='assets/packages/lity/lity.minb51b.js?ver=5.13.5' id='mec-lity-script-js'></script>
<script type='text/javascript' src='assets/packages/colorbrightness/colorbrightness.minb51b.js?ver=5.13.5' id='mec-colorbrightness-script-js'></script>
<script type='text/javascript' src='assets/packages/owl-carousel/owl.carousel.minb51b.js?ver=5.13.5' id='mec-owl-carousel-script-js'></script>
<script type='text/javascript' src='../../wp-admin/js/editor.min5697.js?ver=5.5.3' id='editor-js'></script>
<script type='text/javascript' id='editor-js-after'>
window.wp.oldEditor = window.wp.editor;
</script>
<script type='text/javascript' id='quicktags-js-extra'>
/* <![CDATA[ */
var quicktagsL10n = {"closeAllOpenTags":"Close all open tags","closeTags":"close tags","enterURL":"Enter the URL","enterImageURL":"Enter the URL of the image","enterImageDescription":"Enter a description of the image","textdirection":"text direction","toggleTextdirection":"Toggle Editor Text Direction","dfw":"Distraction-free writing mode","strong":"Bold","strongClose":"Close bold tag","em":"Italic","emClose":"Close italic tag","link":"Insert link","blockquote":"Blockquote","blockquoteClose":"Close blockquote tag","del":"Deleted text (strikethrough)","delClose":"Close deleted text tag","ins":"Inserted text","insClose":"Close inserted text tag","image":"Insert image","ul":"Bulleted list","ulClose":"Close bulleted list tag","ol":"Numbered list","olClose":"Close numbered list tag","li":"List item","liClose":"Close list item tag","code":"Code","codeClose":"Close code tag","more":"Insert Read More tag"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-includes/js/quicktags.min5697.js?ver=5.5.3' id='quicktags-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/vendor/wp-polyfill.min89b1.js?ver=7.4.4' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wp-polyfill-js-after'>
( 'fetch' in window ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-fetch.min6e0e.js?ver=3.0.0"></scr' + 'ipt>' );( document.contains ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-node-contains.min2e00.js?ver=3.42.0"></scr' + 'ipt>' );( window.DOMRect ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min2e00.js?ver=3.42.0"></scr' + 'ipt>' );( window.URL && window.URL.prototype && window.URLSearchParams ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-url.min5aed.js?ver=3.6.4"></scr' + 'ipt>' );( window.FormData && window.FormData.prototype.keys ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-formdata.mine9bd.js?ver=3.0.12"></scr' + 'ipt>' );( Element.prototype.matches && Element.prototype.closest ) || document.write( '<script src="../../wp-includes/js/dist/vendor/wp-polyfill-element-closest.min4c56.js?ver=2.0.2"></scr' + 'ipt>' );
</script>
<script type='text/javascript' src='../../wp-includes/js/dist/dom-ready.mina7c8.js?ver=db63eb2f693cb5e38b083946b14f0684' id='wp-dom-ready-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/i18n.min77be.js?ver=bb7c3c45d012206bfcd73d6a31f84d9e' id='wp-i18n-js'></script>
<script type='text/javascript' id='wp-a11y-js-translations'>
( function( domain, translations ) {
var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
localeData[""].domain = domain;
wp.i18n.setLocaleData( localeData, domain );
} )( "default", { "locale_data": { "messages": { "": {} } } } );
</script>
<script type='text/javascript' src='../../wp-includes/js/dist/a11y.mind7ed.js?ver=13971b965470c74a60fa32d392c78f2f' id='wp-a11y-js'></script>
<script type='text/javascript' id='wplink-js-extra'>
/* <![CDATA[ */
var wpLinkL10n = {"title":"Insert\/edit link","update":"Update","save":"Add Link","noTitle":"(no title)","noMatchesFound":"No results found.","linkSelected":"Link selected.","linkInserted":"Link inserted.","minInputLength":"3"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-includes/js/wplink.min5697.js?ver=5.5.3' id='wplink-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/widget.mine899.js?ver=1.11.4' id='jquery-ui-widget-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/position.mine899.js?ver=1.11.4' id='jquery-ui-position-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/menu.mine899.js?ver=1.11.4' id='jquery-ui-menu-js'></script>
<script type='text/javascript' id='jquery-ui-autocomplete-js-extra'>
/* <![CDATA[ */
var uiAutocompleteL10n = {"noResults":"No results found.","oneResult":"1 result found. Use up and down arrow keys to navigate.","manyResults":"%d results found. Use up and down arrow keys to navigate.","itemSelected":"Item selected."};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/autocomplete.mine899.js?ver=1.11.4' id='jquery-ui-autocomplete-js'></script>
<script type='text/javascript' id='thickbox-js-extra'>
/* <![CDATA[ */
var thickboxL10n = {"next":"Next >","prev":"< Prev","image":"Image","of":"of","close":"Close","noiframes":"This feature requires inline frames. You have iframes disabled or your browser does not support them.","loadingAnimation":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-includes\/js\/thickbox\/loadingAnimation.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='../../wp-includes/js/thickbox/thickboxab87.js?ver=3.1-20121105' id='thickbox-js'></script>
<script type='text/javascript' src='../../wp-includes/js/underscore.min4511.js?ver=1.8.3' id='underscore-js'></script>
<script type='text/javascript' src='../../wp-includes/js/shortcode.min5697.js?ver=5.5.3' id='shortcode-js'></script>
<script type='text/javascript' src='../../wp-admin/js/media-upload.min5697.js?ver=5.5.3' id='media-upload-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/mouse.mine899.js?ver=1.11.4' id='jquery-ui-mouse-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/sortable.mine899.js?ver=1.11.4' id='jquery-ui-sortable-js'></script>
<script type='text/javascript' src='assets/packages/plyr/plyr.polyfilled.minb34d.js?ver=1.7.4' id='tutor-plyr-js'></script>
<script type='text/javascript' src='assets/packages/SocialShare/SocialShare.minb34d.js?ver=1.7.4' id='tutor-social-share-js'></script>
<script type='text/javascript' src='assets/js/tutorb34d.js?ver=1.7.4' id='tutor-main-js'></script>
<script type='text/javascript' id='tutor-frontend-js-extra'>
/* <![CDATA[ */
var _tutorobject = {"ajaxurl":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","nonce_key":"_wpnonce","_wpnonce":"c1ab78139e","placeholder_img_src":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-content\/plugins\/tutor\/assets\/images\/placeholder.jpg","enable_lesson_classic_editor":"","text":{"assignment_text_validation_msg":"Assignment answer can not be empty"}};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/tutor-frontb34d.js?ver=1.7.4' id='tutor-frontend-js'></script>
<script type='text/javascript' src='assets/js/classroom-frontend.js' id='tutor-gc-frontend-js-js'></script>
<script type='text/javascript' src='../../wp-includes/js/jquery/ui/slider.mine899.js?ver=1.11.4' id='jquery-ui-slider-js'></script>
<script type='text/javascript' src='assets/js/jquery-ui-timepicker8a54.js?ver=1.0.0' id='tutor_zoom_timepicker_js-js'></script>
<script type='text/javascript' src='assets/js/moment.min8a54.js?ver=1.0.0' id='tutor_zoom_moment_js-js'></script>
<script type='text/javascript' src='assets/js/moment-timezone-with-data.min8a54.js?ver=1.0.0' id='tutor_zoom_moment_tz_js-js'></script>
<script type='text/javascript' src='assets/js/jquery.countdown.min8a54.js?ver=1.0.0' id='tutor_zoom_countdown_js-js'></script>
<script type='text/javascript' src='assets/js/frontend8a54.js?ver=1.0.0' id='tutor_zoom_frontend_js-js'></script>
<script type='text/javascript' src='assets/js/common8a54.js?ver=1.0.0' id='tutor_zoom_common_js-js'></script>
<script type='text/javascript' src='assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/meric-saudi-arabia\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/yellostack.com\/meric-saudi-arabia\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/frontend/add-to-cart.min83b6.js?ver=4.6.2' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/meric-saudi-arabia\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/frontend/woocommerce.min83b6.js?ver=4.6.2' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/meric-saudi-arabia\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_b55c9b3a03f5c541cb37a10ff5878650","fragment_name":"wc_fragments_b55c9b3a03f5c541cb37a10ff5878650","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/frontend/cart-fragments.min83b6.js?ver=4.6.2' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='assets/js/htmd36b.js?ver=1.3.9' id='htm-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/vendor/lodash.min1f28.js?ver=4.17.15' id='lodash-js'></script>
<script type='text/javascript' id='lodash-js-after'>
window.lodash = _.noConflict();
</script>
<script type='text/javascript' src='../../wp-includes/js/dist/vendor/react.minb3b9.js?ver=16.9.0' id='react-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/vendor/react-dom.minb3b9.js?ver=16.9.0' id='react-dom-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/escape-html.min505c.js?ver=f7b0e4c8bb987c1ab79bdda0d9db465b' id='wp-escape-html-js'></script>
<script type='text/javascript' src='../../wp-includes/js/dist/element.min39ef.js?ver=d061952232722fcef7dbe8a686d9996f' id='wp-element-js'></script>
<script type='text/javascript' id='metform-app-js-extra'>
/* <![CDATA[ */
var mf = {"postType":"courses","restURI":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-json\/metform\/v1\/forms\/views\/"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/appd36b.js?ver=1.3.9' id='metform-app-js'></script>
<script type='text/javascript' src='../../wp-content/plugins/elementskit-lite/lib/framework/assets/js/frontend-script5bfb.js?ver=2.0.9.1' id='elementskit-framework-js-frontend-js'></script>
<script type='text/javascript' id='elementskit-framework-js-frontend-js-after'>
	var elementskit = {
        resturl: 'https://yellostack.com/meric-saudi-arabia/wp-json/elementskit/v1/',
    }

	
</script>
<script type='text/javascript' src='assets/js/widget-scripts5bfb.js?ver=2.0.9.1' id='ekit-widget-scripts-js'></script>
<script type='text/javascript' src='assets/js/TweenMax.min7fb9.js?ver=1.5.9' id='tweenmax-js'></script>
<script type='text/javascript' src='assets/js/jquery.easing.1.37fb9.js?ver=1.5.9' id='jquery-easing-js'></script>
<script type='text/javascript' src='assets/js/tilt.jquery.min7fb9.js?ver=1.5.9' id='tilt-js'></script>
<script type='text/javascript' src='assets/js/anime7fb9.js?ver=1.5.9' id='animejs-js'></script>
<script type='text/javascript' src='assets/js/magician7fb9.js?ver=1.5.9' id='magicianjs-js'></script>
<script type='text/javascript' src='assets/js/bootstrap.min077c.js?ver=1.2.9' id='bootstrap-js'></script>
<script type='text/javascript' src='assets/js/popper.min077c.js?ver=1.2.9' id='popper-js'></script>
<script type='text/javascript' src='assets/js/jquery.magnific-popup.min077c.js?ver=1.2.9' id='magnific-popup-js'></script>
<script type='text/javascript' src='assets/js/jquery-mixtub077c.js?ver=1.2.9' id='jquery-mixtub-js'></script>
<script type='text/javascript' src='assets/js/owl.carousel.min077c.js?ver=1.2.9' id='owl-carousel-js'></script>
<script type='text/javascript' src='assets/js/jquery.easypiechart.min077c.js?ver=1.2.9' id='jquery-easypiechart-js'></script>
<script type='text/javascript' id='turitor-script-js-extra'>
/* <![CDATA[ */
var turitor_obj = {"ajax_url":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-admin\/admin-ajax.php","nonce":"169acfc9a8","security":"eeedad3138","blog_sticky_sidebar":"no","logged_in":"","message_login":"You are not logged in"};
/* ]]> */
</script>
<script type='text/javascript' src='assets/js/script077c.js?ver=1.2.9' id='turitor-script-js'></script>
<script type='text/javascript' src='../../wp-includes/js/wp-embed.min5697.js?ver=5.5.3' id='wp-embed-js'></script>
<script type='text/javascript' src='assets/js/goodshare.min5697.js?ver=5.5.3' id='goodshare-js'></script>
<script type='text/javascript' src='assets/js/frontend-modules.min2a45.js?ver=3.0.13' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='assets/lib/dialog/dialog.mina288.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script type='text/javascript' src='assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='assets/lib/swiper/swiper.min48f5.js?ver=5.3.6' id='swiper-js'></script>
<script type='text/javascript' src='assets/lib/share-link/share-link.min2a45.js?ver=3.0.13' id='share-link-js'></script>
<script type='text/javascript' id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.0.13","is_static":false,"legacyMode":{"elementWrappers":true},"urls":{"assets":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":1977,"title":"Advanced%20Leadership%20Skills%20%E2%80%93%20My%20Blog","excerpt":"","featuredImage":"https:\/\/yellostack.com\/meric-saudi-arabia\/wp-content\/uploads\/2020\/11\/Management.png"}};
</script>
<script type='text/javascript' src='assets/js/frontend.min2a45.js?ver=3.0.13' id='elementor-frontend-js'></script>
<script type='text/javascript' src='assets/js/elementor077c.js?ver=1.2.9' id='turitor-main-elementor-js'></script>
<script type='text/javascript' src='assets/js/elementor5bfb.js?ver=2.0.9.1' id='elementskit-elementor-js'></script>
<script type='text/javascript' src='assets/js/jquery.sticky20b9.js?ver=1.0.2' id='elementskit-sticky-content-script-js'></script>
<script type='text/javascript' src='assets/js/main20b9.js?ver=1.0.2' id='elementskit-sticky-content-script-core-js'></script>
<script type='text/javascript' src='assets/js/widget-init7fb9.js?ver=1.5.9' id='elementskit-parallax-widget-init-js'></script>
<script type='text/javascript' src='assets/js/section-init7fb9.js?ver=1.5.9' id='elementskit-parallax-section-init-js'></script>
<script type='text/javascript' src='assets/js/form-picker-editord36b.js?ver=1.3.9' id='metform-js-formpicker-control-editor-js'></script>
<script type='text/javascript' src='assets/js/widgetarea-editor5bfb.js?ver=2.0.9.1' id='elementskit-js-widgetarea-control-editor-js'></script>
	<script type="text/javascript">
	window.wp = window.wp || {};
	window.wp.editor = window.wp.editor || {};
	window.wp.editor.getDefaultSettings = function() {
		return {
			tinymce: {},
			quicktags: {
				buttons: 'strong,em,link,ul,ol,li,code'
			}
		};
	};

			</script>
			<div id="wp-link-backdrop" style="display: none"></div>
	<div id="wp-link-wrap" class="wp-core-ui" style="display: none" role="dialog" aria-labelledby="link-modal-title">
	<form id="wp-link" tabindex="-1">
	<input type="hidden" id="_ajax_linking_nonce" name="_ajax_linking_nonce" value="bff2982925" />		<h1 id="link-modal-title"><?php echo $this->Admin_model->translate("Insert/edit link") ?></h1>
	<button type="button" id="wp-link-close"><span class="screen-reader-text"><?php echo $this->Admin_model->translate("Close") ?></span></button>
	<div id="link-selector">
		<div id="link-options">
			<p class="howto" id="wplink-enter-url"><?php echo $this->Admin_model->translate("Enter the destination URL") ?></p>
			<div>
				<label><span><?php echo $this->Admin_model->translate("URL") ?></span>
				<input id="wp-link-url" type="text" aria-describedby="wplink-enter-url" /></label>
			</div>
			<div class="wp-link-text-field">
				<label><span><?php echo $this->Admin_model->translate("Link Text") ?></span>
				<input id="wp-link-text" type="text" /></label>
			</div>
			<div class="link-target">
				<label><span></span>
				<input type="checkbox" id="wp-link-target" /> <?php echo $this->Admin_model->translate("Open link in a new tab") ?></label>
			</div>
		</div>
		<p class="howto" id="wplink-link-existing-content"><?php echo $this->Admin_model->translate("Or link to existing content") ?></p>
		<div id="search-panel">
			<div class="link-search-wrapper">
				<label>
					<span class="search-label"><?php echo $this->Admin_model->translate("Search") ?></span>
					<input type="search" id="wp-link-search" class="link-search-field" autocomplete="off" aria-describedby="wplink-link-existing-content" />
					<span class="spinner"></span>
				</label>
			</div>
			<div id="search-results" class="query-results" tabindex="0">
				<ul></ul>
				<div class="river-waiting">
					<span class="spinner"></span>
				</div>
			</div>
			<div id="most-recent-results" class="query-results" tabindex="0">
				<div class="query-notice" id="query-notice-message">
					<em class="query-notice-default"><?php echo $this->Admin_model->translate("No search term specified. Showing recent items.") ?></em>
					<em class="query-notice-hint screen-reader-text"><?php echo $this->Admin_model->translate("Search or use up and down arrow keys to select an item.") ?></em>
				</div>
				<ul></ul>
				<div class="river-waiting">
					<span class="spinner"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="submitbox">
		<div id="wp-link-cancel">
			<button type="button" class="button"><?php echo $this->Admin_model->translate("Cancel") ?></button>
		</div>
		<div id="wp-link-update">
			<input type="submit" value="Add Link" class="button button-primary" id="wp-link-submit" name="wp-link-submit">
		</div>
	</div>
	</form>
	</div>
	
</body>

<!-- Mirrored from yellostack.com/meric-saudi-arabia/courses/advanced-leadership-skills/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 11 Nov 2020 09:19:24 GMT -->
</html>
