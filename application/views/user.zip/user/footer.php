<div class="ekit-template-content-markup ekit-template-content-footer ekit-template-content-theme-support">
<div data-elementor-type="wp-post" data-elementor-id="521" class="elementor elementor-521" data-elementor-settings="[]">
<div class="elementor-inner">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-d552d7b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d552d7b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
<div class="elementor-background-overlay"></div>
<div class="container-fluid elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7406752" data-id="7406752" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f35046a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f35046a" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
<div class="container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-90a3482" data-id="90a3482" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-e37d5fd elementor-widget elementor-widget-elementskit-heading" data-id="e37d5fd" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
<?php echo $this->Admin_model->translate("Company") ?>
</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
</div>
<div class="elementor-element elementor-element-8a77926 elementor-widget elementor-widget-text-editor" data-id="8a77926" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p class="foot_txt"><?php echo $this->Admin_model->translate("In 1958 MEIRC ( Middle East Industrial Relations Consultants ) was founded in Athens serving the Gulf market. In 1982, the company was fully transformed to MEIRC Saudi Arabia with full rights and privileges.") ?></p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5f292b4" data-id="5f292b4" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap cour_type">
<div class="elementor-element elementor-element-07cfac9 elementor-widget elementor-widget-elementskit-heading" data-id="07cfac9" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
<?php echo $this->Admin_model->translate("Training Courses") ?> 
</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
</div>
<div class="elementor-element elementor-element-7033745 ts-footer-menu elementor-widget elementor-widget-wp-widget-nav_menu" data-id="7033745" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="wp-widget-nav_menu.default">
<div class="elementor-widget-container">
<div class="menu-categories-container"><ul id="menu-categories" class="menu">
<li id="menu-item-2704" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2704"><a href="<?php echo base_url();?>user/courses?type=public"><?php echo $this->Admin_model->translate("Public classes") ?></a></li>
<li id="menu-item-2707" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2707"><a href="<?php echo base_url();?>user/in_house"><?php echo $this->Admin_model->translate("In-House") ?></a></li>
<li id="menu-item-2705" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2705"><a href="<?php echo base_url();?>user/comingsoon"><?php echo $this->Admin_model->translate("Online Self-paced") ?></a></li>
<li id="menu-item-2706" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2706"><a href="<?php echo base_url();?>user/courses?type=virtual"><?php echo $this->Admin_model->translate("Virtual instructor led") ?>  </a></li>
<li id="menu-item-2707" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2707"><a href="<?php echo base_url();?>user/courses?type=certified"><?php echo $this->Admin_model->translate("Certified Courses") ?></a></li>
</ul></div></div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-741dbfe" data-id="741dbfe" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-5941500 elementor-widget elementor-widget-elementskit-heading" data-id="5941500" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" ><div class="elementskit-section-title-wraper ekit_heading_tablet-   ekit_heading_mobile-"><h2 class="elementskit-section-title ">
<?php echo $this->Admin_model->translate("Get in touch") ?>
</h2><div class="ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider elementskit-style-long"><div class="elementskit-border-divider elementskit-style-long"></div></div></div></div>		</div>
</div>
<div class="elementor-element elementor-element-91f569d elementor-widget elementor-widget-text-editor" data-id="91f569d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix">
<p class="foot_txt"><?php echo $this->Admin_model->translate("Email") ?>: info@mericsa.com<br>
<?php echo $this->Admin_model->translate("Phone-no") ?> :&nbsp;  +966133412188<br>
<?php echo $this->Admin_model->translate("Fax-no") ?> :&nbsp;&nbsp;  &nbsp;  &nbsp; +966133415046<br>
<?php echo $this->Admin_model->translate("mobile-no") ?>:&nbsp; &nbsp;+966505949708
</p></div>
</div>
</div>
<div class="elementor-element elementor-element-a02f087 elementor-widget elementor-widget-elementskit-social-share" data-id="a02f087" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-social-share.default">
<div class="elementor-widget-container">
<div class="ekit-wid-con" >		<ul class="ekit_socialshare">
<li class="elementor-repeater-item-a34ffda" data-social="facebook">
<a class="facebook">

<i aria-hidden="true" class="icon icon-facebook"></i>                        
                </a>
</li>
<li class="elementor-repeater-item-d5a0fda" data-social="twitter">
<a class="twitter">

<i aria-hidden="true" class="icon icon-twitter"></i>                        
                </a>
</li>
<li class="elementor-repeater-item-7fb877f" data-social="instagram">
<a class="instagram">

<i aria-hidden="true" class="icon icon-instagram-1"></i>                        
                </a>
</li>
<li class="elementor-repeater-item-53ac344" data-social="linkedin">
<a class="linkedin">

<i aria-hidden="true" class="icon icon-linkedin"></i>                        
                </a>
</li>
</ul>
</div>		</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-95c4384 elementor-widget-divider--view-line elementor-widget elementor-widget-divider" data-id="95c4384" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="divider.default">
<div class="elementor-widget-container">
<div class="elementor-divider">
<span class="elementor-divider-separator">
</span>
</div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-95e7ecd elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="95e7ecd" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
<div class="container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-29b19d2" data-id="29b19d2" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-6ea10fd elementor-widget elementor-widget-turitor-logo" data-id="6ea10fd" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="turitor-logo.default">
<div class="elementor-widget-container">
<div class="turitor-widget-logo">
<a href="<?php echo base_url();?>user">
<img src="<?php echo base_url();?>assets/userassets/img/foot_logo.png" alt="Logo">
</a>
</div>

</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ed2d21d" data-id="ed2d21d" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-7d3f16a elementor-widget elementor-widget-text-editor" data-id="7d3f16a" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix">
<p class="link"><a href=""><?php echo $this->Admin_model->translate("Privacy Policy") ?></a>
<a href=""><?php echo $this->Admin_model->translate("Terms & Condition") ?></a></p>
<p class="link1" style="color:white">© 2021. <?php echo $this->Admin_model->translate("All rights reserved.") ?> &nbsp;&nbsp;<img src="<?php echo base_url();?>assets/userassets/img/card.png" width="150px" height="150px"></p>

</div>
</div>
</div>
</div>
</div>
</div>

</div>
<!-- <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-93d17cb elementor-hidden-tablet" data-id="93d17cb" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-f4dd33e elementor-widget elementor-widget-turitor-back-to-top" data-id="f4dd33e" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="turitor-back-to-top.default">
<div class="elementor-widget-container">

<div class="ts-scroll-box">
<div class="BackTo">
<a href="#">
<i aria-hidden="true" class="tsicon tsicon-up_arrow"></i>				</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div> -->
</div>
</section>

</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>


<script type="text/javascript">
jQuery('.btnsearch').click(function() {
var search = jQuery('#mainsearch').val() ;
//alert(search);
window.location.href = "<?php echo base_url()?>user/courses?search="+search;
});
</script>


 <script type="text/javascript">
jQuery('.slang').on("click",function(){


 
    jQuery.ajax({ 
        type: "POST",
          url : "<?php echo base_url(); ?>user/changelanguage",
            
 
    }).done(function(response){
location.reload() ;
       
    });

})

</script>